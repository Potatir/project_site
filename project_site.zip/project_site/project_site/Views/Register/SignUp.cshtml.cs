using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace project_site.Views.Register
{
    public class SignUpModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
