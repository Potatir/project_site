using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace project_site.Views.Home
{
    public class IndexENGModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
