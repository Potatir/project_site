using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace project_site.Views.Profile
{
    public class UserModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
