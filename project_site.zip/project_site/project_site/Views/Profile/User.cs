﻿namespace project_site.Views.Profile
{
    public class User
    {
    }
}
