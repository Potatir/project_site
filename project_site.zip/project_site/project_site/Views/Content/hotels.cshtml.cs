using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace project_site.Views.Content
{
    public class hotelsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
