using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace project_site.Views.Content
{
    public class MainPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
