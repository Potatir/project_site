﻿namespace project_site.wwwroot.js
{
    public class XOCHY_KYSCHATI_OTPYSTITE_PZ
    {
    }
}
