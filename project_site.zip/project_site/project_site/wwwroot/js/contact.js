(function ($) {
    $(function () {



    });
})(jQuery);